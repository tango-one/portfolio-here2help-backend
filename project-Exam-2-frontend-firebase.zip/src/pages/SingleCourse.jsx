import CourseContent from "../components/CourseContent";

const SingleCourse = () => {
  return (
    <div className="container">
      <CourseContent />
    </div>
  );
};

export default SingleCourse;
