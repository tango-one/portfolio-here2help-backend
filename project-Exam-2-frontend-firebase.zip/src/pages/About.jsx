// components
import AboutContent from "../components/About";

const About = () => {
  return (
    <div className="container">
      <AboutContent />
    </div>
  );
};

export default About;
