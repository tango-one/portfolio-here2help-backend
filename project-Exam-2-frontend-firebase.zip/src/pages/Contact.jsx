// components
import ContactForm from "../components/Contact/ContactForm";

const Contact = () => {
  return (
    <div className="container">
      <ContactForm />
    </div>
  );
};

export default Contact;
