import React from "react";

// components
import CustomTabs from "../components/Courses/Tabs";

const Courses = () => {
  return (
    <div className="container">
      <CustomTabs />
    </div>
  );
};

export default Courses;
